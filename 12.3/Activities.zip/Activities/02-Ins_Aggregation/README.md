# Instructor Demo

## Reference

[The Metropolitan Museum of Art](https://www.metmuseum.org/) (2022). The Metropolitan Museum of Art Collection API <https://metmuseum.github.io/>. Licensed under the [Creative Commons 0 License](https://creativecommons.org/publicdomain/zero/1.0/)

Accessed Oct 3, 2022. Data collected from departmentId=5 ("Arts of Africa, Oceania, and the Americas") and search string "animal".

- - -

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
