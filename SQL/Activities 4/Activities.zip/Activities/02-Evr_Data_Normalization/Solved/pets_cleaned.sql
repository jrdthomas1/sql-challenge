INSERT INTO pets_cleaned VALUES
(1,'Wei','Bao','Dog','Bath'),
(2,'Dzigbode','Nini','Dog','Walk'),
(3,'Akmal','Bastet','Cat','Litter change'),
(4,'Carly','Nala','Cat','Litter change'),
(5,'Mikayla','Thumper','Rabbit','Feed'),
(6,'Frederick','Cooper','Dog','Walk'),
(6,'Frederick','Marshmallow','Rabbit','Feed'),
(1,'Wei','Lian','Dog','Bath');