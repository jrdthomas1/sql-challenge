INSERT INTO pets VALUES
(1,'Wei','Bao, Lian','Dog','Bath, Bath'),
(2,'Dzigbode','Nini','Dog','Walk'),
(3,'Akmal','Bastet','Cat','Litter change'),
(4,'Carly','Nala','Cat','Litter change'),
(5,'Mikayla','Thumper','Rabbit','Feed'),
(6,'Frederick','Cooper, Marshmallow','Dog, Rabbit','Walk, Feed');