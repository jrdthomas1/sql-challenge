# Data Normalization

## First Form Normalization

* Each field in a table row row should contain a single value.

* Each row is unique.

## Second Form Normalization

* Be in first normal form.

* Single Column for Primary Key.

  * Identifies the table uniquely

## Third Form Normalization

* Be in second normal form.

* Contain non-transitively dependent columns.
