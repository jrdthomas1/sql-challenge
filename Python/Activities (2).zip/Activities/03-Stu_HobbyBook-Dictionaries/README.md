# Hobby Book: Dictionaries

In this activity, you will create and access dictionaries that are based on your own hobbies.

## Instructions

1. Create a dictionary to store the following information:

    * Your name
    * Your age
    * A list of a few of your hobbies
    * A dictionary that includes a few days and the time you typically wake up on those days

2. Print out your name, how many hobbies you have, and a time you typically wake up during the week.

- - -

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
