# Module Playground

In this activity, you will have the opportunity to explore and play around with some Python modules.

## Instructions

There are tons of built-in modules for Python. Review some of Python's modules and play around with them. Use the following link:

[List of Built-In Python Modules](https://docs.python.org/3/py-modindex.html)

—

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
