# Query 1 - Creating dbs, inserting data and finding data
